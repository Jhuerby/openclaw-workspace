# 🚀 一键部署指南

## 方式 1：Netlify Drop（最简单，推荐）

### 步骤：

1. **打开 Netlify Drop**
   ```
   https://app.netlify.com/drop
   ```

2. **拖拽文件夹**
   - 打开上面的链接
   - 把 `voice-monitor` 文件夹拖到网页上
   - 等待上传完成（约 10 秒）

3. **获取链接**
   - 部署完成后会生成一个链接
   - 格式：`https://xxx-xxx-xxx.netlify.app`
   - 可以自定义名字

4. **完成！**
   - 链接可以立即访问
   - 手机/电脑都能打开
   - 免费 HTTPS

---

## 方式 2：Vercel（同样简单）

### 步骤：

1. **打开 Vercel**
   ```
   https://vercel.com/new
   ```

2. **导入项目**
   - 登录 GitHub
   - 选择导入 Git 仓库
   - 或者拖拽文件夹

3. **部署**
   - 点击 Deploy
   - 等待 30 秒
   - 获得链接

---

## 方式 3：本地快速测试（临时）

### 在教室电脑运行：

```bash
cd /Users/huangjie/.openclaw/workspace/projects/voice-monitor
python3 -m http.server 8080
```

然后访问：`http://localhost:8080`

---

## 📱 手机测试

部署完成后，在手机浏览器打开生成的链接即可测试！

---

## ⚙️ 配置麦克风权限

**第一次使用需要允许麦克风：**

1. 点击"开始监测"
2. 浏览器会询问麦克风权限
3. 点击"允许"
4. 开始使用！

**如果无法访问麦克风：**
- 检查浏览器设置
- 确保使用 HTTPS（Netlify/Vercel 自动提供）
- 使用 Chrome/Safari 浏览器

---

## 🎯 快速操作

你现在可以：

1. **立即测试** - 用上面的方式 3 本地测试
2. **正式部署** - 用方式 1 Netlify Drop（最简单）
3. **让我帮你** - 告诉我你的选择，我继续协助

---

**推荐：现在先用方式 3 本地测试，确认功能正常后再部署到 Netlify！**
